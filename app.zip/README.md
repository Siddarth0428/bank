# Bank Management Web App (Frontend-only)

This project is a **frontend-only** bank management system using **HTML/CSS/JS**.
- **No backend**
- **In-memory mock data** (resets on refresh)
- Includes **animated UI**

## Run
Just open:
- `index.html`

No build step required.

